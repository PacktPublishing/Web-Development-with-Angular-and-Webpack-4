import 'bootstrap'
import './scss/index.scss'

console.log($().jquery)
