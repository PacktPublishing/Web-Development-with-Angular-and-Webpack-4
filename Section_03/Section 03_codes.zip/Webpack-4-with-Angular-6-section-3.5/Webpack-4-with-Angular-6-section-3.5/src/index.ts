console.log('hi');

import {Car} from './Car';

const car: Car = new Car();

car.go();

