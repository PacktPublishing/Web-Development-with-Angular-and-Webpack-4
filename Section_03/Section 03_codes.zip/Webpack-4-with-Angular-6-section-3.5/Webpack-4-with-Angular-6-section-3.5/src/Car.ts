export class Car {
    public go (): void {
        console.log(<string> 'vroom');
    }
}

