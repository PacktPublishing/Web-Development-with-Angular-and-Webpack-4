import { Component, OnInit } from '@angular/core';

@Component({
  //selector: 'app-lazyloading-list',
  templateUrl: './lazyloading-list.component.html',
  styleUrls: ['./lazyloading-list.component.css']
})
export class LazyloadingListComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
