class Car {
    go () {
        console.log('hello');
    }
}

