import {Component} from '@angular/core';

@Component({
	selector: 'app-root',
	templateUrl: './app-root.component.html'
})
export class AppRootComponent {
	title: String = 'Angular 5/W4 App started';
}