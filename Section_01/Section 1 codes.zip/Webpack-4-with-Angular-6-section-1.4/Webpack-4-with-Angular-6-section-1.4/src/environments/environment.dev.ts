export const environment = {
  platform: 'DEV'
};
