export const environment = {
  platform: 'PROD'
};
